<?php
	$con=mysqli_connect('localhost','root','','sistema_ecommerce');